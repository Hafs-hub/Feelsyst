# CONTEXT.md — Feelsyst

> Fichier de mémoire partagée du projet. À mettre à jour à chaque intervention (Claude ou Kimi K3) et à transmettre en début de session.
> Dernière mise à jour : 18/08/2026 — Kimi K3

---

## 1. Vision

Feelsyst est une plateforme SaaS qui dote chaque PME française d'une équipe de 8 agents IA spécialisés, accessibles sans compétence technique. Conformité RGPD, données hébergées en Europe.

- **Site** : https://www.feelsyst.com (aussi feelsyst.vercel.app)
- **Modèle** : essai gratuit 7 jours sans CB, puis Starter 29 € / Pro 79 € / Illimité 179 € par mois

## 2. Stack technique

| Couche | Technologie |
|---|---|
| Frontend | HTML/CSS/JS vanilla, hébergé sur Vercel |
| Backend | API routes Node.js (Vercel serverless) |
| Base de données | Supabase PostgreSQL |
| IA | API Anthropic Claude Sonnet (via proxy serveur) |
| Paiement | Stripe (webhook dédié) |
| Email | Brevo |

## 3. Les 8 agents

Aria (Stratégie) · Nova (Marketing) · Rex (Prospection) · Vera (Finance) · Lumi (Support) · Lex (Juridique) · Pulse (Analytics) · Atlas (Formation)

## 4. Fichiers principaux

- `index.html` — landing page
- `auth.html` — connexion / inscription (avec présélection du plan tarifaire)
- `dashboard.html` — espace client avec chat agents
- `feelsyst-admin.html` — admin panel fondateur
- `api/proxy-ai.js` — proxy vers l'API Anthropic
- `api/register.js`, `api/login.js`, `api/me.js` — authentification
- `api/webhook-stripe.js` — gestion des paiements
- `lib/supabase.js` — fonctions base de données

## 5. Tables Supabase

`clients`, `payments`, `usage`, `prospects`, `support_tickets`, `agent_configs`, `admin_logs`, `admin_alerts`, `sessions`

## 6. Historique des interventions

### 18/08/2026 — Audit initial (Kimi K3)
**Points forts** : positionnement multi-agents différenciant, page légère (~39 Ko), meta description et sitemap OK, page d'inscription fonctionnelle, discours rassurant (RGPD, Europe, sans engagement).
**Faiblesses identifiées** :
- Aucune balise Open Graph / Twitter Card (partages réseaux sociaux sans aperçu)
- Pas de preuve sociale (témoignages, logos, chiffres)
- SEO : une seule page, pas de contenu éditorial ni de pages par agent
- Cadrage juridique des promesses « finance » et « juridique » à renforcer dans les CGV

### 18/08/2026 — Incident déploiement (RÉSOLU)
Symptôme : Vercel servait un ancien commit, le nouveau site ne s'affichait pas.
Résolution : nouveau déploiement en production, statut Prêt, branche `main`, commit `11a5f79` (message mentionnant un fichier json — probablement ajout d'un `vercel.json`).
Rappel : le bouton « Annulation instantanée » (Instant Rollback) permet de revenir à ce déploiement sain en un clic.

## 7. Backlog priorisé

### P0 — Sécurité & conformité (avant acquisition clients)
- [ ] Vérifier qu'aucune clé API (Anthropic, Supabase service key, Stripe) n'est exposée côté client — tout doit passer par les routes `api/`
- [ ] Activer et auditer le RLS (Row Level Security) sur toutes les tables Supabase
- [ ] Rate limiting sur `api/proxy-ai.js` (protection contre l'abus et les coûts API)
- [ ] Mentions légales + CGV + politique de confidentialité (obligatoires en France)
- [ ] Registre de traitement RGPD + bandeau cookies si tracking

### P1 — SEO & acquisition
- [ ] Balises Open Graph / Twitter Cards + image de partage 1200×630
- [ ] Une page dédiée par agent (/agents/rex, /agents/vera…) pour le référencement
- [ ] Contenu éditorial ciblant les requêtes PME (« automatiser prospection PME », etc.)
- [ ] Données structurées Schema.org (SoftwareApplication, FAQPage)

### P2 — Produit & conversion
- [ ] Preuve sociale sur la landing (témoignages, chiffres d'usage)
- [ ] Onboarding guidé premier usage (activer un premier agent en 2 min)
- [ ] Tracking des événements clés (inscription, activation agent, conversion essai → payant)

### P3 — Pilotage
- [ ] Dashboard fondateur : MRR, churn, usage par agent (table `usage`), coûts API Anthropic par client
- [ ] Alertes admin (table `admin_alerts`) sur erreurs API et échecs de paiement Stripe

## 8. Protocole de passation Claude ↔ Kimi K3

Format de message à utiliser à chaque changement d'intervenant :

```
CONTEXTE : (résumé en 2 lignes)
DERNIÈRES MODIFS : (fichiers touchés, commits)
PROBLÈME / TÂCHE : (précis, avec messages d'erreur si applicable)
PROCHAINE ÉTAPE PRÉVUE : (si définie)
```

Rôles par défaut (modifiable par le fondateur) :
- **Claude** : développement itératif du code, debug, nouvelles features
- **Kimi K3** : audits transverses, veille (SEO, concurrence, réglementation), livrables documents, analyse de données, assets marketing
- **Fondateur (Hafs)** : orchestration, arbitrage, déploiement

## 9. Variables d'environnement (référence — valeurs JAMAIS dans ce fichier)

`ANTHROPIC_API_KEY` · `SUPABASE_URL` · `SUPABASE_SERVICE_KEY` · `STRIPE_SECRET_KEY` · `STRIPE_WEBHOOK_SECRET` · `BREVO_API_KEY`

> Gérées dans Vercel → Settings → Environment Variables. Vérifier qu'elles sont actives pour Production ET Preview.
